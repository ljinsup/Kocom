cems.startAnalysis <-
function(injson, Service) { 
    cems.continueAnalysis(injson=injson, Service=Service, index="1")
  }
