cems.startAnalysis <-
function(injson, Service) { 
  print("****************************************")
  print("*                                      *")
  print("*          1st  Analysis Start         *")
  print("*                                      *")
  print("****************************************")
    cems.continueAnalysis(injson=injson, Service=Service, index="1")
  }
