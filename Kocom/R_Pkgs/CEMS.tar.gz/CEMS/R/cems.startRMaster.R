cems.startRMaster <-
function (json_str) {
    # 초기화
    cems.init()
    print("Input Sensor Data")
    print(json_str)
    #   Debugging(json_str, text="startMaster(json_str): ")
    print("****************************************")
    print("*                                      *")
    print("*            Analysis Start            *")
    print("*                                      *")
    print("****************************************")
    
    # input JSON assign
    input <- fromJSON(json_str)
    data <- as.list(unlist(input$sensors_data))
    tgid <- input$tgid
    # Mongo DB Connection
    # DB <- connectMongo(Addr=User_DB_Host, DB="scconfig", port = User_DB_Port)
    print(paste("User_DB_Host:", User_DB_Host, "User_DB_Port", User_DB_Port, sep = " "))
    DB <- connectMongo(Addr=User_DB_Host, DB="tgconfig", port = User_DB_Port)
    
    print(tgid)
    # get Service Data from DB-
    query <- mongo.bson.buffer.create()
    mongo.bson.buffer.append(query, "tgid", tgid)
    query <- mongo.bson.from.buffer(query)
    fields <- mongo.bson.buffer.create()
    mongo.bson.buffer.append(fields, "service", 1)
    fields <- mongo.bson.from.buffer(fields)
    cursor <- mongo.find(mongo = DB,
                         ns = paste(attr(DB, "db"), tgid, sep = "."),
                         query = query,
                         fields = fields)
  
    # Service list 
  service <- list()
  while(mongo.cursor.next(cursor)){
    res <- mongo.cursor.value(cursor)
    service <- mongo.bson.to.list(res)     
  }
  
    list <- ls(envir=.GlobalEnv)
    
    if(length(service) == 0)
      return("Not Maching Service")
    
    log <- list()
    log$service <- service
    log$LOG <- "service"
    log$TIME <- Sys.time()
    insertHistory(input$tgid, log)
    
    for(i in 1:length(service)) {
      
      if(!is.include(service$service[[i]]$requirement$sensor, names(data)) )
        return()
      
      if(!is.integer0(grep(x=nodelist[[1]], pattern="[:]"))) {
        rs <- RS.connect( host=unlist(strsplit(unlist(nodelist), split=":"))[1],
                          port=unlist(strsplit(unlist(nodelist), split=":"))[2] )
      }else{
        rs <- RS.connect( host=nodelist[[1]] )      
      }
      
      RS.eval(rs, require(CEMS))
      RS.eval(rs, CEMS::cems.init())
      
      for(name in list) {
        RS.assign(rs, name, get(name))
      }
      RS.assign(rs, "json_str", json_str)
      RS.assign(rs, "Service", service$service[[i]])
      print("eval")
      RS.eval(rs, x=cems.startRSlave(injson=json_str, Service=Service), wait=FALSE)
      print("collect")
      
      RS.close(rs)
    }
      return()
  }
