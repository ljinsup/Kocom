Predicting <-
function(x, df) {
    #   Debugging(x, df, text="Method Predicting(x, df): ")
  
  if(names(x) == "GA"
     || names(x) == "GB"
     || names(x) == "VB"
     || names(x) == "IR"
     || names(x) == "DB"
     || names(x) == "SH"
     || names(x) == "CS"){
    value <- as.numeric(x)
    value <- value/65535*100
    }
  else if(names(x) == "AC"){
    value <- as.numeric(x)
    value <- value/350*100
  }
  else if(names(x) == "FL"
          || names(x) == "IR"){
    value <- as.numeric(x)
    value <- value/1*100
  }
  else if(names(x) == "TH"){
    value <- as.numeric(x)
    value <- value/130*100
  }
  else if(names(x) == "HU"){
    value <- as.numeric(x)
    value <- value/100*100
  }
  
  df <- df
  m <- arima(df)
  
  MAX <- max(df)
  MIN <- min(df)
  
  predictvalue <- (as.numeric(predict(m)$pred)-MIN)/(MAX-MIN)*100
  
  publicvalue <- (as.numeric(df[nrow(df),])-MIN)/(MAX-MIN)*100
  
  list <- list()
  
  print(paste("Public:", publicvalue, "Predicting:", predictvalue, sep = " "))
  if(max(value, predictvalue, publicvalue) == value) {
    result <- 1
  }
  else if(min(value, predictvalue, publicvalue) == value) {
    result <- 3
  }
  else {
    result <- 2
  }
  
  if(publicvalue - predictvalue < 0){
    list <- list(result=result)
  }
  else {
    list <- list(result=result+3)
  }
  
  return(list)
}
