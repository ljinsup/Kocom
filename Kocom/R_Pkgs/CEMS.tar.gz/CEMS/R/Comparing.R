Comparing <-
function(x, df) {
    #   Debugging(x, df, text="Method Compare(x, df): ")
  
  if(names(x) == "GA"
     || names(x) == "GB"
     || names(x) == "VB"
     || names(x) == "IR"
     || names(x) == "DB"
     || names(x) == "SH"
     || names(x) == "CS"){
    value <- as.numeric(x)
    value <- value/65535*100
  }
  else if(names(x) == "AC"){
    value <- as.numeric(x)
    value <- value/350*100
  }
  else if(names(x) == "FL"
          || names(x) == "IR"){
    value <- as.numeric(x)
    value <- value/1*100
  }
  else if(names(x) == "TH"){
    value <- as.numeric(x)
    value <- value/130*100
  }
  else if(names(x) == "HU"){
    value <- as.numeric(x)
    value <- value/100*100
  }
  
  
  MAX <- apply(df, 2, max)
  MIN <- apply(df, 2, min)
  MEAN <- mean(tail(df))
  
  publicvalue <- (MEAN-MIN)/(MAX-MIN)*100
  
  print(paste("MAX:", MAX, "MEAN:", MEAN, "MIN:", MIN, sep = " "))

  return(publicvalue)
}
