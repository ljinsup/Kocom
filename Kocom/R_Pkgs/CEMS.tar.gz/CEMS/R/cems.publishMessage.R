cems.publishMessage <-
function(json_str) {
    checkpkg("rJava")
    ip <- MQTT_Server_Host
    port <- MQTT_Server_Port
    key <- Key
    JSON <- fromJSON(json_str)
    
    if(JSON$type == "act") {
      topic <- paste(key, JSON$type, inputMessage$tgid, sep="/")
      pushtopic <- "SC/PUSH/USER_01"
      
      msg <- json_str
      
      push <- fromJSON(json_str)
      push$type <- "msgACT"
      push$userid <- "USER_01"
      push$tgid <- "TG_01"
      push$data <- paste(push$actuator_id, push$action, sep = " : ")
      push <- toJSON(push)
    }
    
    print(paste("IP:", ip))
    print(paste("Port:", port))
    print(paste("Topic:", topic))
    print(paste("Message:", msg))
    
    print(paste("Topic:", pushtopic))
    print(paste("Message:", push))
    
    .jinit("./MQTTPublisher.jar")
    mqtt <- .jnew("mqtt/MqttSend")
    
    mqtt$SEND(ip, port, topic, msg)  
    mqtt$SEND(ip, port, pushtopic, push)  
  }
