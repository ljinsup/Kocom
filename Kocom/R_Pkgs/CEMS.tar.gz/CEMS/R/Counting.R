Counting <-
function(x, df) {
    #   Debugging(x, df, text="Method Counting(x, df): ")  
    
  if(names(x) == "GA"
     || names(x) == "GB"
     || names(x) == "VB"
     || names(x) == "IR"
     || names(x) == "DB"
     || names(x) == "SH"
     || names(x) == "CS"){
    value <- as.numeric(x)
    value <- value/65535*100
  }
  else if(names(x) == "AC"){
    value <- as.numeric(x)
    value <- value/350*100
  }
  else if(names(x) == "FL"
          || names(x) == "IR"){
    value <- as.numeric(x)
    value <- value/1*100
  }
  else if(names(x) == "TH"){
    value <- as.numeric(x)
    value <- value/130*100
  }
  else if(names(x) == "HU"){
    value <- as.numeric(x)
    value <- value/100*100
  }

  data <- subset(x=df, select=names(x))
  
  data <- na.omit(data)
  
  x <- DataForming(as.data.frame(x))
  data <- DataForming(as.data.frame(data))
  
  data <- count(data)
  per <- data$freq/sum(data$freq)*100
  names(per) <- "per"
  data$per <- per
  
  return(max(data$per))
}
