cems.init <-
function(){ 
    checkpkg("rjson", "rmongodb", "plyr", "rJava", "RSclient")
  }
